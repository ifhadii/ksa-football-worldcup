
<?php include "header.php"; ?>
        <!-- ***** Breadcrumb Area Start ***** -->
        <section class="section breadcrumb-area d-flex align-items-center" style="background: rgb(16 36 18);">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <!-- Breamcrumb Content -->
                        <div class="breadcrumb-content d-flex flex-column align-items-center text-center">
                            <h2 class="text-white text-uppercase mb-3" style="color: white !important;">من نحن</h2>
                            <ol class="breadcrumb d-flex justify-content-center">
                                <li class="breadcrumb-item text-white active">المدن</li>
                                  <li class="breadcrumb-item"><a class="text-uppercase text-white" href="index.php">الرئيسية</a></li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- ***** Breadcrumb Area End ***** -->

        <!--====== Call To Action Area End ======-->
<?php include "footer.php"; ?>
