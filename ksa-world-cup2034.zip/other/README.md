# ksa-football-worldcup
A freelance project focused on software maintenance and feature support for a website dedicated to the FIFA World Cup with an emphasis on KSA (Saudi Arabia). The task involved ensuring optimal performance, fixing bugs, and maintaining content accuracy during and after tournament events.
